opencv_version = "4.12.0.88"
contrib = False
headless = False
rolling = False
ci_build = True